 # Roku-IPTV
 The Simplest Application for Roku you can use to watch IPTV

 Please, feel free to fork and PR. Now it's just a draft
 
 Thanks Bugsy™ for ideas and updates. I had to rewrite many things, but he made good job.

See here how enable developer mode for ROKU : https://blog.roku.com/developer/developer-setup-guide 

Device Setup Guide for Roku Developers
ctraganos - May 16th, 2019
Our 5 minute guide to getting started with Roku development

Roku_Device_Setup_-_Secret_Code
https://image.roku.com/blog/developer/files/2016/02/Roku_Device_Setup_-_Secret_Code.png


Overview
The first step to building channels on the Roku platform is setting up a development environment. In this guide, we will cover the essential steps setting up “developer mode” using any Roku device.

Steps:
Setup your Roku Device in “Developer Mode”
Accessing the Development Application Installer
Requirements to follow this guide:
A Roku device: roku.com/products/compare
A Roku account: my.roku.com/signup
Enroll in the Dev Program developer.roku.com
1. Setup your Roku Device in “Developer Mode”
Using your Roku remote (or Roku iPhone Remote App), enter the following sequence:


https://image.roku.com/blog/developer/files/2016/02/image05-2.png

 

Note: This secret code enables the Developer Application Installer, which allows you to test channel applications directly on your Roku device.

Follow the steps provided in the following Developer Settings sign up flow:

Developer Settings

Once you begin this process, the dialog will prompt you to restart to continue to the process.

Note: Make sure the save the Roku device URL!

After enabling the installer, review and complete the SDK License Agreement:
You can review the full text at docs.roku.com/doc/developersdk/en-us

Read agreement

The following prompt will ask to set a password for the Roku device:
This ensures your device is protected on your local area network.
https://image.roku.com/blog/developer/files/2016/02/image00-1.png


enter dev mode password

This completes the steps for enabling Developer mode, continue to the next section for loading applications onto the device.

2. Accessing the Development Application Installer
After reboot, open a web browser and enter the Roku device URL (i.e. http://192.168.x.x)
https://image.roku.com/blog/developer/files/2016/02/image11-e1454565719777.png


Logging into Roku Device

Once the page successfully opens, you have successfully connected to your Roku device in ‘Developer Mode’.
The primary screen will show the development application installer:

Development Application Installer
https://image.roku.com/blog/developer/files/2016/02/image08.png

Next steps
Now that you have configured and enabled Developer Mode on your Roku device, it’s time to create a sample application.

Our introductory ‘Hello World’ Guide offers a downloadable sample application for developing on the Roku Platform.

Hello World

After the Setup Guides – Explore the Developer docs!
Go to the developer documentation and explore the methods, parameters, and syntax for building rich and complex channel applications on the Roku platform.

For samples regarding our new XML framework, Roku SceneGraph, go to bit.ly/rokudevxml to get started!
